package com.fashioncart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FashioncartApplicationTests {

	@Test
	void contextLoads() {
	}

}
