package com.fashioncart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FashioncartApplication {

	public static void main(String[] args) {
		SpringApplication.run(FashioncartApplication.class, args);
	}

}
