// src/Components/Expenses.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AddExpenseModal from './AddExpenseModal';
import { Bar, Pie } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ArcElement,
} from 'chart.js';

// Register the necessary Chart.js components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const Expenses = () => {
    const [expensesData, setExpensesData] = useState([]);
    const [totalExpenses, setTotalExpenses] = useState(0);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [sortOption, setSortOption] = useState('date'); // New state for sort option

    // Fetch expenses data from the backend API
    const fetchExpensesData = async () => {
        setLoading(true);
        try {
            const response = await axios.get('/api/expenses'); // Update with your actual endpoint
            setExpensesData(response.data);
            calculateTotalExpenses(response.data);
        } catch (error) {
            console.error("Error fetching expenses data:", error);
        } finally {
            setLoading(false);
        }
    };

    // Calculate total expenses
    const calculateTotalExpenses = (data) => {
        const total = data.reduce((acc, expense) => acc + parseFloat(expense.amount), 0);
        setTotalExpenses(total);
    };

    useEffect(() => {
        fetchExpensesData();
    }, []);

    // Add new expense from modal form
    const addNewExpense = (newExpense) => {
        const expenseWithId = { ...newExpense, id: Date.now() }; // Adding a unique ID
        const updatedExpensesData = [...expensesData, expenseWithId];
        setExpensesData(updatedExpensesData);
        calculateTotalExpenses(updatedExpensesData);
    };

    // Sort expenses based on the selected option
    const sortExpenses = (expenses) => {
        const sortedExpenses = [...expenses];
        if (sortOption === 'date') {
            sortedExpenses.sort((a, b) => new Date(b.date) - new Date(a.date)); // Newest to oldest
        } else if (sortOption === 'amount') {
            sortedExpenses.sort((a, b) => b.amount - a.amount); // Highest to lowest
        } else if (sortOption === 'item') {
            sortedExpenses.sort((a, b) => a.item.localeCompare(b.item)); // Alphabetical order
        }
        return sortedExpenses.slice(0, 10); // Return only the top 10 items
    };

    // Prepare data for the bar chart
    const prepareBarChartData = () => {
        const labels = [...new Set(expensesData.map(expense => expense.item))]; // Unique items
        const amounts = labels.map(item => {
            return expensesData
                .filter(expense => expense.item === item)
                .reduce((acc, expense) => acc + parseFloat(expense.amount), 0);
        });

        return {
            labels: labels,
            datasets: [
                {
                    label: 'Expense Amount (₹)',
                    data: amounts,
                    backgroundColor: 'rgba(255, 99, 132, 0.6)', // Bar color
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1,
                },
            ],
        };
    };

    // Prepare data for the pie chart with vibrant colors
    const preparePieChartData = () => {
        const labels = [...new Set(expensesData.map(expense => expense.item))];
        const amounts = labels.map(item => {
            return expensesData
                .filter(expense => expense.item === item)
                .reduce((acc, expense) => acc + parseFloat(expense.amount), 0);
        });

        return {
            labels: labels,
            datasets: [
                {
                    data: amounts,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)',
                        'rgba(255, 159, 64, 0.6)',
                    ], // Vibrant colors for pie chart
                    borderColor: 'rgba(255, 255, 255, 1)',
                    borderWidth: 2,
                },
            ],
        };
    };

    // Show loading state
    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h1>Expense Transactions</h1>
            <button onClick={() => setShowModal(true)}>New Expense</button>
            <h2>Total Expenses: ₹{totalExpenses.toFixed(2)}</h2>

            {/* Sort Options */}
            <div>
                <label htmlFor="sortOptions">Sort by:</label>
                <select
                    id="sortOptions"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value)}
                >
                    <option value="date">Date (Newest to Oldest)</option>
                    <option value="amount">Amount (Highest to Lowest)</option>
                    <option value="item">Item Name (A-Z)</option>
                </select>
            </div>

            {/* Combined Charts Container */}
            <div style={{ display: 'flex', justifyContent: 'space-around', margin: '20px 0' }}>
                {/* Bar Chart for Expense Amount */}
                <div style={{ width: '45%', height: '300px' }}>
                    <Bar 
                        data={prepareBarChartData()} 
                        options={{ 
                            responsive: true, 
                            maintainAspectRatio: false, 
                            plugins: { legend: { position: 'top' } } 
                        }} 
                    />
                </div>

                {/* Pie Chart for Expense Distribution */}
                <div style={{ width: '45%', height: '300px' }}>
                    <Pie 
                        data={preparePieChartData()} 
                        options={{ 
                            responsive: true, 
                            maintainAspectRatio: false, 
                            plugins: { 
                                legend: { position: 'top' },
                                tooltip: {
                                    callbacks: {
                                        label: (tooltipItem) => {
                                            return `${tooltipItem.label}: ₹${tooltipItem.raw}`;
                                        },
                                    },
                                },
                            },
                        }} 
                    />
                </div>
            </div>

            {/* Table for displaying expenses data */}
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item</th>
                        <th>Amount (₹)</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    {sortExpenses(expensesData).map((expense) => (
                        <tr key={expense.id}>
                            <td>{expense.id}</td>
                            <td>{expense.item}</td>
                            <td>₹{parseFloat(expense.amount).toFixed(2)}</td>
                            <td>{new Date(expense.date).toLocaleDateString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* Add Expense Modal */}
            <AddExpenseModal 
                showModal={showModal} 
                closeModal={() => setShowModal(false)} 
                addNewExpense={addNewExpense} 
            />
        </div>
    );
};

export default Expenses;