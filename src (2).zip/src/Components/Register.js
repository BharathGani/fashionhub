// src/components/Register.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Register = ({ onRegister }) => {
    const [username, setUsername] = useState(''); // Username state
    const [email, setEmail] = useState(''); // Email state
    const [password, setPassword] = useState(''); // Password state
    const [confirmPassword, setConfirmPassword] = useState(''); // Confirm Password state
    const [showPassword, setShowPassword] = useState(false); // State for toggling password visibility
    const [showConfirmPassword, setShowConfirmPassword] = useState(false); // State for toggling confirm password visibility
    const [errorMessage, setErrorMessage] = useState(''); // State for error messages
    const navigate = useNavigate();

    const handleRegister = async () => {
        setErrorMessage(''); // Reset error message on new registration attempt
        if (password !== confirmPassword) {
            setErrorMessage('Passwords do not match');
            return;
        }
        try {
            const response = await axios.post('http://localhost:3307/register', { username, email, password });
            alert(response.data.message);
            onRegister(username); // Call the onRegister prop with username
            navigate('/login'); // Redirect to login page after registration
        } catch (error) {
            setErrorMessage('Registration failed: ' + (error.response?.data?.message || 'Please try again.'));
        }
    };

    return (
        <div 
            className="register"
            style={{
                backgroundImage: 'url("https://img.freepik.com/free-psd/shopping-vertical-background_23-2150409471.jpg")', // Replace with your image path
                backgroundSize: 'cover',
                backgroundPosition: 'center', 
                height: '80vh', 
                display: 'flex', 
                flexDirection: 'column', 
                color: 'white',
                
            }}
        >
            <h1>Fashion Hub</h1>
            <h2>Create Your Account</h2>
            {errorMessage && <p className="error-message">{errorMessage}</p>}
            <div className="form-group">
                <input
                    type="text"
                    placeholder="Name"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
            </div>
            <div className="form-group">
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
            </div>
            <div className="form-group">
                <div className="password-input">
                    <input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <span
                        className="toggle-password"
                        onClick={() => setShowPassword(!showPassword)} // Toggle password visibility
                        style={{ cursor: 'pointer', marginLeft: '10px' }}
                    >
                        {showPassword ? '👁' : '👁‍🗨'} {/* Eye symbols for show/hide */}
                    </span>
                </div>
            </div>
            <div className="form-group">
                <div className="password-input">
                    <input
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="Confirm Password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                    />
                    <span
                        className="toggle-password"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)} // Toggle confirm password visibility
                        style={{ cursor: 'pointer', marginLeft: '10px' }}
                    >
                        {showConfirmPassword ? '👁' : '👁‍🗨'} {/* Eye symbols for show/hide */}
                    </span>
                </div>
            </div>
            <button onClick={handleRegister}>Register</button>
            <p>
                Already have an account?{' '}
                <button className="login-button" onClick={() => navigate('/login')}>Login</button>
            </p>
        </div>
    );
};

export default Register;