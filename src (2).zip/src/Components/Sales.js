import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AddSaleModal from './AddSaleModal';
import { Bar, Pie } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ArcElement,
} from 'chart.js';
import { FaTrash } from 'react-icons/fa';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const Sales = () => {
    const [salesData, setSalesData] = useState([]);
    const [totalSales, setTotalSales] = useState(0);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);

    const fetchSalesData = async () => {
        setLoading(true);
        try {
            const response = await axios.get('/api/sales');
            setSalesData(response.data);
            calculateTotalSales(response.data);
        } catch (error) {
            console.error("Error fetching sales data:", error);
        } finally {
            setLoading(false);
        }
    };

    const calculateTotalSales = (data) => {
        const total = data.reduce((acc, sale) => 
            acc + sale.items.reduce((itemAcc, item) => itemAcc + parseFloat(item.amount), 0)
        , 0);
        setTotalSales(total);
    };

    useEffect(() => {
        fetchSalesData();
    }, []);

    const addNewSale = (newSale) => {
        const saleWithId = { ...newSale, transactionId: Date.now() };
        const updatedSalesData = [...salesData, saleWithId];
        setSalesData(updatedSalesData);
        calculateTotalSales(updatedSalesData);
    };

    const deleteSale = (transactionId) => {
        const updatedSalesData = salesData.filter(sale => sale.transactionId !== transactionId);
        setSalesData(updatedSalesData);
        calculateTotalSales(updatedSalesData);
    };

    const printInvoice = (sale) => {
        const invoiceWindow = window.open('', '', 'height=700,width=900');
        invoiceWindow.document.write(`
            <html>
                <head>
                    <title>Fashion Hub - Invoice</title>
                    <style>
                        body { font-family: 'Helvetica', sans-serif; color: #333; padding: 30px; }
                        .invoice-container { max-width: 700px; margin: 0 auto; }
                        .header { text-align: center; margin-bottom: 20px; }
                        .header h1 { font-size: 28px; color: #4b0082; margin-bottom: 5px; }
                        .header p { font-size: 14px; color: #4b0082; }
                        .details, .items-table { width: 100%; margin-bottom: 20px; }
                        .details td { padding: 8px; }
                        .items-table th, .items-table td { padding: 12px; border: 1px solid #ddd; text-align: left; }
                        .items-table th { background-color: #f4f4f4; color: #4b0082; }
                        .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
                        .total { font-weight: bold; font-size: 16px; color: #333; }
                    </style>
                </head>
                <body>
                    <div class="invoice-container">
                        <div class="header">
                            <h1>Fashion Hub Invoice</h1>
                            <p>Your Trusted Fashion Partner</p>
                        </div>
                        <table class="details">
                            <tr>
                                <td><strong>Transaction ID:</strong> ${sale.transactionId}</td>
                                <td><strong>Date:</strong> ${new Date(sale.date).toLocaleDateString()}</td>
                            </tr>
                            <tr>
                                <td><strong>Customer Name:</strong> ${sale.customerName}</td>
                                <td><strong>Phone Number:</strong> ${sale.phoneNumber}</td>
                            </tr>
                        </table>
                        <table class="items-table">
                            <tr>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Amount (₹)</th>
                            </tr>
                            ${sale.items.map(item => `
                                <tr>
                                    <td>${item.name}</td>
                                    <td>${item.quantity}</td>
                                    <td>₹${item.amount}</td>
                                </tr>
                            `).join('')}
                        </table>
                        <p class="total">Total Amount: ₹${sale.items.reduce((acc, item) => acc + parseFloat(item.amount), 0).toFixed(2)}</p>
                        <div class="footer">
                            Thank you for shopping with Fashion Hub!<br>
                            For more inquiries, visit our website at <strong>www.fashionhub.com</strong>
                        </div>
                    </div>
                </body>
            </html>
        `);
        invoiceWindow.document.close();
        invoiceWindow.print();
    };
    

    const prepareBarChartData = () => {
        const items = salesData.flatMap(sale => sale.items.map(item => item.name));
        const uniqueItems = [...new Set(items)];
        const amounts = uniqueItems.map(item => {
            return salesData
                .flatMap(sale => sale.items)
                .filter(i => i.name === item)
                .reduce((acc, i) => acc + parseFloat(i.amount), 0);
        });

        return {
            labels: uniqueItems,
            datasets: [
                {
                    label: 'Sales Amount (₹)',
                    data: amounts,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1,
                },
            ],
        };
    };

    const preparePieChartData = () => {
        const items = salesData.flatMap(sale => sale.items.map(item => item.name));
        const uniqueItems = [...new Set(items)];
        const amounts = uniqueItems.map(item => {
            return salesData
                .flatMap(sale => sale.items)
                .filter(i => i.name === item)
                .reduce((acc, i) => acc + parseFloat(i.amount), 0);
        });

        const vibrantColors = [
            'rgba(255, 99, 132, 0.6)', 'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)', 'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)', 'rgba(255, 159, 64, 0.6)',
            'rgba(255, 0, 255, 0.6)', 'rgba(0, 255, 255, 0.6)',
        ];

        const colors = vibrantColors.slice(0, uniqueItems.length);

        return {
            labels: uniqueItems,
            datasets: [
                {
                    data: amounts,
                    backgroundColor: colors,
                    borderColor: 'rgba(255, 255, 255, 1)',
                    borderWidth: 2,
                },
            ],
        };
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h1 className="sales">Sales Transactions</h1>
            <button onClick={() => setShowModal(true)}>New Sale</button>
            <h2>Total Sales: ₹{totalSales.toFixed(2)}</h2>

            <div style={{ display: 'flex', justifyContent: 'space-around', margin: '20px 0' }}>
                <div style={{ width: '45%', height: '300px' }}>
                    <Bar 
                        data={prepareBarChartData()} 
                        options={{ 
                            responsive: true, 
                            maintainAspectRatio: false, 
                            plugins: { legend: { position: 'top' } } 
                        }} 
                    />
                </div>
                <div style={{ width: '45%', height: '300px' }}>
                    <Pie 
                        data={preparePieChartData()} 
                        options={{ 
                            responsive: true, 
                            maintainAspectRatio: false, 
                            plugins: { legend: { position: 'top' } } 
                        }} 
                    />
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Transaction ID</th>
                        <th>Customer Name</th>
                        <th>Phone Number</th>
                        <th>Items</th>
                        <th>Total Amount (₹)</th>
                        <th>Date</th>
                        <th>Actions</th>
                        <th>Print Invoice</th>
                    </tr>
                </thead>
                <tbody>
                    {salesData.map((sale) => (
                        <tr key={sale.transactionId}>
                            <td>{sale.transactionId}</td>
                            <td>{sale.customerName}</td>
                            <td>{sale.phoneNumber}</td>
                            <td>
                                {sale.items.map((item, idx) => (
                                    <div key={idx}>{item.name} (₹{item.amount})</div>
                                ))}
                            </td>
                            <td>{sale.items.reduce((acc, item) => acc + parseFloat(item.amount), 0)}</td>
                            <td>{sale.date}</td>
                            <td>
                                <FaTrash onClick={() => deleteSale(sale.transactionId)} style={{ cursor: 'pointer', color: 'red' }} />
                            </td>
                            <td>
                                <button onClick={() => printInvoice(sale)}>
                                    Print Invoice
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <AddSaleModal showModal={showModal} closeModal={() => setShowModal(false)} addNewSale={addNewSale} />
        </div>
    );
};

export default Sales;
