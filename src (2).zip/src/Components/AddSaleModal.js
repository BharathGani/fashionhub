import React, { useState } from 'react';

const AddSaleModal = ({ showModal, closeModal, addNewSale }) => {
    const [customerName, setCustomerName] = useState(''); // State for customer name
    const [phoneNumber, setPhoneNumber] = useState(''); // New state for phone number
    const [items, setItems] = useState([{ name: '', quantity: '', amount: '' }]);
    const [date, setDate] = useState(new Date().toISOString().substring(0, 10));

    const handleItemChange = (index, e) => {
        const updatedItems = items.map((item, i) =>
            i === index ? { ...item, [e.target.name]: e.target.value } : item
        );
        setItems(updatedItems);
    };

    const handleAddItem = () => {
        setItems([...items, { name: '', quantity: '', amount: '' }]);
    };

    const handleRemoveItem = (index) => {
        const updatedItems = items.filter((_, i) => i !== index);
        setItems(updatedItems);
    };

    const handleSubmit = () => {
        if (customerName && phoneNumber && items.every(item => item.name && item.quantity && item.amount)) {
            addNewSale({ customerName, phoneNumber, items, date });
            closeModal();
        } else {
            alert('Please fill in all fields, including customer name and phone number.');
        }
    };

    if (!showModal) {
        return null;
    }

    return (
        <div className="modal-overlay">
            <div className="modal">
                <h2>Add New Sale</h2>
                
                {/* Customer Name Field */}
                <label>Customer Name</label>
                <input 
                    type="text" 
                    value={customerName} 
                    onChange={(e) => setCustomerName(e.target.value)} 
                    placeholder="Customer name" 
                />

                {/* Phone Number Field */}
                <label>Phone Number</label>
                <input 
                    type="tel" 
                    value={phoneNumber} 
                    onChange={(e) => setPhoneNumber(e.target.value)} 
                    placeholder="Phone number" 
                />

                {items.map((item, index) => (
                    <div key={index} className="item-entry">
                        <label>Item</label>
                        <input 
                            type="text" 
                            name="name" 
                            value={item.name} 
                            onChange={(e) => handleItemChange(index, e)} 
                            placeholder="Item name" 
                        />
                        <label>Quantity</label>
                        <input 
                            type="number" 
                            name="quantity" 
                            value={item.quantity} 
                            onChange={(e) => handleItemChange(index, e)} 
                            placeholder="Quantity" 
                        />
                        <label>Amount</label>
                        <input 
                            type="number" 
                            name="amount" 
                            value={item.amount} 
                            onChange={(e) => handleItemChange(index, e)} 
                            placeholder="Amount in ₹" 
                        />
                        <button onClick={() => handleRemoveItem(index)} disabled={items.length === 1}>
                            Remove Item
                        </button>
                    </div>
                ))}
                
                <button onClick={handleAddItem}>Add Another Item</button>

                <label>Date</label>
                <input 
                    type="date" 
                    name="date" 
                    value={date} 
                    onChange={(e) => setDate(e.target.value)} 
                />

                <div>
                    <button onClick={handleSubmit}>Save</button>
                    <button onClick={closeModal}>Cancel</button>
                </div>
            </div>
        </div>
    );
};

export default AddSaleModal;
