// src/components/LandingPage.js
import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for redirection

const LandingPage = () => {
  const navigate = useNavigate(); // Hook for navigation

  return (
    <div className="landing-page">
      <header className="header" style={{ backgroundImage: 'url("https://img.freepik.com/premium-photo/luxury-shopping-mall-department-clothing-store-interior_652667-376.jpg?w=826")', backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <h1 id="Example1">Welcome to Fashion Hub</h1>
        <p id="Example">Your ultimate shopping destination for trendy clothing and accessories!</p>
        
        {/* Container for buttons */}
        <div className="button-group">
          <button className="cta-button" onClick={() => navigate('/login')}>Login</button>
          <button className="cta-button" onClick={() => navigate('/register')}>Register</button>
        </div>
      </header>

      {/* Section for Featured Categories */}
      <section className="categories">
        <h2>Shop by Category</h2>
        <div className="category-list">
          <div className="category">
            <img src="https://th.bing.com/th/id/OIP.YCsxUYl9nbpZqrSn0qt8ywHaE8?w=305&h=204&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="Men's Clothing" />
            <h3>Men's Fashion</h3>
            <p>Explore the latest trends in men's wear.</p>
          </div>
          <div className="category">
            <img src="https://th.bing.com/th/id/OIP.Ub-wQHto9vAV0fKsfj5puAHaFu?rs=1&pid=ImgDetMain" alt="Women's Clothing" />
            <h3>Women's Fashion</h3>
            <p>Discover the hottest styles for women.</p>
          </div>
          <div className="category">
            <img src="https://img.freepik.com/premium-photo/clothing-accessories-men-women-ready-travel-life-style_11304-1345.jpg" alt="Accessories" />
            <h3>Accessories</h3>
            <p>Complete your look with trendy accessories.</p>
          </div>
        </div>
      </section>

      {/* Section for Promotions or Discounts */}
      <section className="promotions"style={{ backgroundImage: 'url("https://ctoscredit.com.my/wp-content/uploads/2016/11/3.Article_festive-shopping-image_cover-min.png")', backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <h2 id="Example1">Exclusive Offers</h2>
        <div className="promotion-list">
          <div className="promotion">
            <h3>Buy 1 Get 1 Free</h3>
            <p>On selected Men's and Women's clothing.</p>
          </div>
          <div className="promotion">
            <h3>Flat 50% Off</h3>
            <p>On accessories and footwear. Limited time only!</p>
          </div>
          <div className="promotion">
            <h3>Seasonal Sale</h3>
            <p>Shop the latest collection with up to 70% off.</p>
          </div>
        </div>
      </section>

      {/* Section for Customer Reviews */}
      <section className="reviews" style={{ backgroundImage: 'url("")', backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <h2>What Our Customers Say</h2>
        <div className="review-list">
          <div className="review">
            <p>"I love the variety of clothes and the fast delivery!" - Jane D.</p>
          </div>
          <div className="review">
            <p>"Amazing quality and great customer service!" - John P.</p>
          </div>
          <div className="review">
            <p>"The best place to shop for my entire family!" - Lisa K.</p>
          </div>
        </div>
      </section>

      <footer className="footer">
        <p>© 2024 Fashion Hub. All rights reserved.</p>
        <div className="footer-links">
          <a href="#categories">Categories</a>
          <a href="#offers">Offers</a>
          <a href="#about">About Us</a>
          <a href="#contact">Contact</a>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;