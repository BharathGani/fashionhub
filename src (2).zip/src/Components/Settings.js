// src/components/Settings.js
import React, { useState } from 'react';

const Settings = () => {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [theme, setTheme] = useState('light');
  const [username, setUsername] = useState('User123');
  const [email, setEmail] = useState('user@example.com');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSaveChanges = () => {
    // Logic to save changes (to a server or local storage)
    alert('Changes saved successfully!');
  };

  const handleDeleteAccount = () => {
    // Logic to delete the account (should ideally ask for confirmation)
    alert('Account deleted successfully!');
  };

  return (
    <div className="settings-container">
      <h2>Settings</h2>
      <div className="settings-content">
        <div className="settings-section">
          <h3>Account Information</h3>
          <div className="form-group">
            <label>Username:</label>
            <input 
              type="text" 
              value={username} 
              onChange={(e) => setUsername(e.target.value)} 
            />
          </div>
          <div className="form-group">
            <label>Email:</label>
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
            />
          </div>
          <div className="form-group">
            <label>Password:</label>
            <input 
              type="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
            />
          </div>
          <div className="form-group">
            <label>Confirm Password:</label>
            <input 
              type="password" 
              value={confirmPassword} 
              onChange={(e) => setConfirmPassword(e.target.value)} 
            />
          </div>
        </div>

        <div className="settings-section">
          <h3>Preferences</h3>
          <div className="form-group">
  <label>Enable Notifications:</label>
  <input 
    type="checkbox" 
    checked={notificationsEnabled} 
    onChange={(e) => setNotificationsEnabled(e.target.checked)} 
    className="custom-checkbox" // Add a class for styling
  />
</div>

          <div className="form-group">
            <label>Theme:</label>
            <select value={theme} onChange={(e) => setTheme(e.target.value)}>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </div>
        </div>

        <div className="actions">
          <button onClick={handleSaveChanges}>Save Changes</button>
          <button className="delete-account" onClick={handleDeleteAccount}>Delete Account</button>
        </div>
      </div>
    </div>
  );
};

export default Settings;