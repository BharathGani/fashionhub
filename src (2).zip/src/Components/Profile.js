// src/components/Profile.js
import React, { useState } from 'react';

const Profile = () => {
  const [username, setUsername] = useState('User123');
  const [email, setEmail] = useState('user@example.com');
  const [phone, setPhone] = useState('1234567890');
  const [address, setAddress] = useState('123 Fashion Street, Style City');
  const [bio, setBio] = useState('I love shopping for the latest trends!');
  const [profilePicture, setProfilePicture] = useState(null);

  const handleSaveChanges = () => {
    // Logic to save changes (to a server or local storage)
    alert('Profile updated successfully!');
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicture(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="profile-container">
      <h2>Profile Information</h2>
      <div className="profile-section">
        <div className="profile-field">
          <label>Profile Picture:</label>
          <div className="profile-picture-upload">
            {profilePicture && (
              <img src={profilePicture} alt="Profile Preview" className="profile-picture" />
            )}
            <input type="file" accept="image/*" onChange={handleFileChange} />
          </div>
        </div>
        <div className="profile-field">
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="profile-field">
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="profile-field">
          <label>Phone:</label>
          <input
            type="text"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="1234567890"
          />
        </div>
        <div className="profile-field">
          <label>Address:</label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            rows="3"
            placeholder="Your delivery address..."
          />
        </div>
        <div className="profile-field">
          <label>Bio:</label>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            rows="4"
            placeholder="Tell us about yourself..."
          />
        </div>
      </div>
      <div className="actions">
        <button onClick={handleSaveChanges} className="save-btn">Save Changes</button>
      </div>
    </div>
  );
};

export default Profile;
